﻿HTML Versions of CSUN 2018 Slide Presentations

by Jamal Mazrui, 2018-04-13

Since PDF and PPTX formats tend to lack accessibility, whereas HTML tends to support it, I converted the many slide files to .htm versions in order to maximize likely accessibility for screen reader users.  The files are collected in this zip archive.  

Note that these files are the results of automated conversions, omitting images and most styling.  Some files also seem to have incomplete content.  

If a file has a .html rather than a .htm extension, however, then it is an original web page of the shared, slide presentation rather than the result of a conversion.  In such a case, no downloadable, single-file version of the presentation was found.  Any style or image files associated with the .html file are not included.
